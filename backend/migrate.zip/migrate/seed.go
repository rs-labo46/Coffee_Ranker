package migrate

import (
	"errors"
	"fmt"
	"os"
	"strings"
	"time"

	"coffee-ranker/entity"
	"coffee-ranker/model"

	"golang.org/x/crypto/bcrypt"
	"gorm.io/gorm"
	"gorm.io/gorm/clause"
)

const (
	seedBeanCount    = 100
	seedArticleCount = 100
)

// Seedは開発・Postman確認に必要な初期データを作成する。
// 認証確認用Admin、公開済みBean/Article、ランキング対象、初期metricsを冪等に投入する。
func Seed(db *gorm.DB) error {
	admin, err := SeedAdmin(db)
	if err != nil {
		return err
	}

	if err := SeedContent(db, admin); err != nil {
		return err
	}

	return nil
}

// SeedAdminはSEED_ADMIN_EMAILとSEED_ADMIN_PASSWORDがある場合だけ管理者を作成する。
// 既存emailがある場合はrole/status/passwordをseed値へ揃える。
func SeedAdmin(db *gorm.DB) (*model.User, error) {
	email := strings.ToLower(strings.TrimSpace(os.Getenv("SEED_ADMIN_EMAIL")))
	password := os.Getenv("SEED_ADMIN_PASSWORD")
	if email == "" || password == "" {
		return nil, nil
	}

	hash, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		return nil, err
	}

	var user model.User
	err = db.Where("email = ?", email).First(&user).Error
	if err == nil {
		user.Name = "Seed Admin"
		user.PasswordHash = string(hash)
		user.Role = entity.UserRoleAdmin
		user.Status = entity.UserStatusActive
		if err := db.Save(&user).Error; err != nil {
			return nil, err
		}
		return &user, nil
	}
	if !errors.Is(err, gorm.ErrRecordNotFound) {
		return nil, err
	}

	user = model.User{
		Name:         "Seed Admin",
		Email:        email,
		PasswordHash: string(hash),
		Role:         entity.UserRoleAdmin,
		Status:       entity.UserStatusActive,
		TokenVersion: 0,
	}
	if err := db.Create(&user).Error; err != nil {
		return nil, err
	}
	return &user, nil
}

// SeedContentは画面確認・検索・ランキング・推薦確認に必要な公開コンテンツを作成する。
func SeedContent(db *gorm.DB, admin *model.User) error {
	now := time.Now()

	beans, err := seedBeans(db)
	if err != nil {
		return err
	}

	articles, err := seedArticles(db, now)
	if err != nil {
		return err
	}

	if err := seedBeanArticles(db, beans, articles); err != nil {
		return err
	}

	targets, err := seedRankTargets(db, beans, articles)
	if err != nil {
		return err
	}

	if err := seedContentMetrics(db, targets, now); err != nil {
		return err
	}

	if admin != nil {
		if err := seedAdminInterestProfiles(db, admin.ID, now); err != nil {
			return err
		}
	}

	return nil
}

func seedBeans(db *gorm.DB) ([]*model.Bean, error) {
	items := buildSeedBeans()
	for _, item := range items {
		if err := upsertBean(db, item); err != nil {
			return nil, err
		}
	}
	return items, nil
}

func buildSeedBeans() []*model.Bean {
	type beanPattern struct {
		namePrefix string
		origin     string
		region     string
		farm       string
		variety    string
		roast      entity.RoastLevel
		acidity    int
		bitterness int
		flavor     int
		aroma      int
		body       int
		note       string
		detail     string
		imageURL   string
	}

	patterns := []beanPattern{
		{"Ethiopia Yirgacheffe", "Ethiopia", "Yirgacheffe", "Gedeb Smallholders", "Heirloom", entity.RoastLevelLight, 5, 1, 5, 5, 2, "jasmine, lemon, peach", "ジャスミンのような香りとレモンの明るさが出やすい浅煎り。軽い口当たりで、朝の一杯や作業前のリセットに向く。", "https://images.unsplash.com/photo-1447933601403-0c6688de566e?auto=format&fit=crop&w=1200&q=80"},
		{"Brazil Cerrado", "Brazil", "Cerrado", "Fazenda Primavera", "Mundo Novo", entity.RoastLevelMedium, 2, 3, 3, 3, 4, "nuts, chocolate, caramel", "ナッツ、チョコレート、キャラメルの甘さを感じやすい中煎り。酸味が控えめで、毎日飲む定番として扱いやすい。", "https://images.unsplash.com/photo-1517701604599-bb29b565090c?auto=format&fit=crop&w=1200&q=80"},
		{"Guatemala Antigua", "Guatemala", "Antigua", "Finca La Soledad", "Bourbon", entity.RoastLevelMedium, 4, 3, 4, 4, 3, "orange, cocoa, spice", "オレンジのような酸味とココアの甘さが重なるバランス型。香りとコクの両方を見たいランキング確認に使いやすい。", "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=1200&q=80"},
		{"Indonesia Mandheling", "Indonesia", "Sumatra", "Lintong Estate", "Typica", entity.RoastLevelDark, 1, 5, 3, 4, 5, "earthy, dark chocolate, herbs", "深いコクとハーブ感、ダークチョコの余韻が出やすい深煎り。ミルクと合わせる豆や夜の一杯として見せやすい。", "https://images.unsplash.com/photo-1509042239860-f550ce710b93?auto=format&fit=crop&w=1200&q=80"},
		{"Kenya Nyeri", "Kenya", "Nyeri", "Gichathaini Factory", "SL28", entity.RoastLevelLight, 5, 2, 5, 4, 3, "blackcurrant, grapefruit, syrup", "カシスやグレープフルーツのような輪郭が強い浅煎り。酸味評価、Good評価、再検索ログの確認に向く。", "https://images.unsplash.com/photo-1459755486867-b55449bb39ff?auto=format&fit=crop&w=1200&q=80"},
		{"Colombia Huila", "Colombia", "Huila", "Finca El Diviso", "Caturra", entity.RoastLevelMedium, 4, 2, 4, 4, 3, "apple, brown sugar, citrus", "りんご、ブラウンシュガー、柑橘の印象を持つ中煎り。甘さと酸味のバランスを推薦理由に出しやすい。", "https://images.unsplash.com/photo-1494314671902-399b18174975?auto=format&fit=crop&w=1200&q=80"},
		{"Costa Rica Tarrazu", "Costa Rica", "Tarrazu", "La Pastora", "Catuai", entity.RoastLevelMedium, 4, 2, 4, 4, 3, "honey, orange, almond", "はちみつ、オレンジ、アーモンドのようなまとまりがある豆。苦味を抑えた中煎り候補として使いやすい。", "https://images.unsplash.com/photo-1511537190424-bbbab87ac5eb?auto=format&fit=crop&w=1200&q=80"},
		{"Rwanda Huye", "Rwanda", "Huye", "Huye Mountain", "Bourbon", entity.RoastLevelLight, 5, 2, 4, 4, 3, "berry, tea, lemon", "ベリー、紅茶、レモンのような軽さが出やすい浅煎り。香り重視のユーザーへの推薦確認に向く。", "https://images.unsplash.com/photo-1461988320302-91bde64fc8e4?auto=format&fit=crop&w=1200&q=80"},
		{"Honduras Marcala", "Honduras", "Marcala", "Las Flores", "Pacas", entity.RoastLevelMedium, 3, 3, 4, 3, 4, "cacao, pear, nuts", "カカオ、洋梨、ナッツの印象がある中煎り。酸味も苦味も強すぎないため、初回表示の候補にしやすい。", "https://images.unsplash.com/photo-1521302080334-4bebac2763a6?auto=format&fit=crop&w=1200&q=80"},
		{"Peru Cajamarca", "Peru", "Cajamarca", "El Diamante", "Typica", entity.RoastLevelMedium, 3, 2, 4, 3, 3, "floral, milk chocolate, citrus", "花のような香り、ミルクチョコ、柑橘の穏やかさがある豆。保存率の高い日常向け候補として扱う。", "https://images.unsplash.com/photo-1442512595331-e89e73853f31?auto=format&fit=crop&w=1200&q=80"},
		{"Mexico Chiapas", "Mexico", "Chiapas", "Finca Santa Cruz", "Bourbon", entity.RoastLevelDark, 2, 4, 3, 3, 4, "dark chocolate, walnut, spice", "ダークチョコ、くるみ、スパイスの印象がある深煎り。苦味とコクを重視する検索条件の確認に向く。", "https://images.unsplash.com/photo-1511920170033-f8396924c348?auto=format&fit=crop&w=1200&q=80"},
		{"Tanzania Kilimanjaro", "Tanzania", "Kilimanjaro", "Machare Estate", "Kent", entity.RoastLevelLight, 5, 2, 4, 4, 3, "citrus, winey, caramel", "柑橘、ワイニー、キャラメルの余韻が出やすい浅煎り。印象的なカード表示と詳細文確認に使いやすい。", "https://images.unsplash.com/photo-1461023058943-07fcbe16d735?auto=format&fit=crop&w=1200&q=80"},
	}

	roasters := []string{
		"Coffee Ranker Roasters",
		"Seed Lab Coffee",
		"Ranker Daily Roast",
		"Clean Cup Works",
		"Modal Brew Studio",
	}

	items := make([]*model.Bean, 0, seedBeanCount)
	for i := 0; i < seedBeanCount; i++ {
		pattern := patterns[i%len(patterns)]
		lot := i + 1
		name := fmt.Sprintf("%s Lot %03d", pattern.namePrefix, lot)
		if i == 0 {
			name = "Ethiopia Yirgacheffe Light Roast"
		}
		if i == 1 {
			name = "Brazil Cerrado Medium Roast"
		}
		if i == 2 {
			name = "Guatemala Antigua Medium Roast"
		}
		if i == 3 {
			name = "Indonesia Mandheling Dark Roast"
		}

		description := fmt.Sprintf("%s 産地:%s、焙煎度:%s。", pattern.detail, pattern.origin, pattern.roast)

		items = append(items, &model.Bean{
			Name:        name,
			Roaster:     strPtr(roasters[i%len(roasters)]),
			Origin:      strPtr(pattern.origin),
			Region:      strPtr(pattern.region),
			Farm:        strPtr(pattern.farm),
			Variety:     strPtr(pattern.variety),
			RoastLevel:  pattern.roast,
			Acidity:     intPtr(rotateTaste(pattern.acidity, i)),
			Bitterness:  intPtr(rotateTaste(pattern.bitterness, i/2)),
			Flavor:      intPtr(rotateTaste(pattern.flavor, i/3)),
			Aroma:       intPtr(rotateTaste(pattern.aroma, i/4)),
			Body:        intPtr(rotateTaste(pattern.body, i/5)),
			FlavorNote:  strPtr(pattern.note),
			Description: strPtr(description),
			ImageURL:    strPtr(pattern.imageURL),
			IsPublished: true,
		})
	}
	return items
}

func seedArticles(db *gorm.DB, now time.Time) ([]*model.Article, error) {
	items := buildSeedArticles(now)
	for _, item := range items {
		if err := upsertArticle(db, item); err != nil {
			return nil, err
		}
	}
	return items, nil
}

func buildSeedArticles(now time.Time) []*model.Article {
	type articlePattern struct {
		titlePrefix string
		slugPrefix  string
		category    string
		summary     string
		body        string
		imageURL    string
	}

	patterns := []articlePattern{
		{
			titlePrefix: "ハンドドリップの基本手順",
			slugPrefix:  "pour-over-basic",
			category:    "brewing",
			summary:     "粉量、湯温、注ぎ方をそろえて、家庭でも味を再現しやすくするための基本手順。",
			body:        "ハンドドリップは、粉量、湯温、注湯回数をそろえるだけで味のぶれがかなり小さくなる。最初に粉全体へ少量の湯を置き、30秒ほど蒸らしてから、中心から外側へゆっくり注ぐ。浅煎りは湯温を高めに、中深煎りは少し低めにすると、酸味や苦味が出すぎにくい。記録を残す場合は、粉量、湯量、抽出時間、味の印象を同じ単位で残すと次回の調整がしやすい。",
			imageURL:    "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&w=1200&q=80",
		},
		{
			titlePrefix: "焙煎度で変わる味の違い",
			slugPrefix:  "roast-level-guide",
			category:    "roast",
			summary:     "浅煎り、中煎り、深煎りで酸味、苦味、香り、コクがどう変わるかを整理する。",
			body:        "焙煎度は、コーヒーの味を選ぶうえで最もわかりやすい軸の一つ。浅煎りは香りや酸味が前に出やすく、果実感のある豆を探す人に向く。中煎りは酸味、甘さ、苦味のバランスが取りやすく、日常使いしやすい。深煎りは苦味とコクが出やすいため、ミルクと合わせる飲み方や重い余韻を求める人に向く。",
			imageURL:    "https://images.unsplash.com/photo-1447933601403-0c6688de566e?auto=format&fit=crop&w=1200&q=80",
		},
		{
			titlePrefix: "酸味が好きな人向けの選び方",
			slugPrefix:  "coffee-acidity-guide",
			category:    "beans",
			summary:     "明るい酸味を楽しみたい人向けに、産地、焙煎度、フレーバーノートの見方をまとめる。",
			body:        "酸味が好きな人は、まず浅煎りのエチオピア、ケニア、ルワンダなどを候補にすると探しやすい。フレーバーノートにレモン、ベリー、カシス、ピーチなどの表現がある豆は、明るい印象になりやすい。ただし酸味は抽出でも変わるため、細かく挽きすぎたり、抽出時間が長すぎたりすると尖って感じることがある。最初は中挽き、高めの湯温、短すぎない抽出で確認するとよい。",
			imageURL:    "https://images.unsplash.com/photo-1517701604599-bb29b565090c?auto=format&fit=crop&w=1200&q=80",
		},
		{
			titlePrefix: "自宅で豆を保存する方法",
			slugPrefix:  "home-coffee-storage",
			category:    "recipe",
			summary:     "豆の香りを落としにくくするための保存場所、容器、飲み切る量の考え方。",
			body:        "コーヒー豆は、光、空気、湿気、熱の影響を受けやすい。家庭では密閉できる容器に入れ、直射日光の当たらない涼しい場所に置くのが扱いやすい。大量に買うと飲み切る前に香りが落ちやすいため、まずは2週間から1か月で使い切れる量にすると失敗しにくい。冷凍保存する場合は、小分けにして結露を避けることが重要になる。",
			imageURL:    "https://images.unsplash.com/photo-1459755486867-b55449bb39ff?auto=format&fit=crop&w=1200&q=80",
		},
		{
			titlePrefix: "フレンチプレスの抽出設計",
			slugPrefix:  "french-press-brewing",
			category:    "brewing",
			summary:     "浸漬式で味を安定させるための粒度、湯温、時間、撹拌の考え方。",
			body:        "フレンチプレスは粉と湯を一定時間触れさせる浸漬式の抽出方法。細かく挽きすぎると粉っぽさや雑味が出やすいため、中粗挽きから粗挽きで始めると調整しやすい。抽出時間は4分前後を基準にし、味が薄ければ粉量を増やすか挽きを少し細かくする。強く押し込むより、ゆっくりプレスして上澄みを注ぐ方が口当たりは安定しやすい。",
			imageURL:    "https://images.unsplash.com/photo-1461988320302-91bde64fc8e4?auto=format&fit=crop&w=1200&q=80",
		},
		{
			titlePrefix: "浅煎り豆の扱い方",
			slugPrefix:  "light-roast-brewing",
			category:    "roast",
			summary:     "浅煎りの香りと酸味を出しやすくするための湯温、挽き目、抽出時間の調整。",
			body:        "浅煎り豆は密度が高く、成分が出にくいことがある。味が薄い場合は、湯温を上げる、挽きを少し細かくする、抽出時間を少し長くするという順番で調整するとよい。酸味が強すぎる場合は、粉量を見直すか、注湯を穏やかにして抽出を安定させる。香りの印象を見たい場合は、飲む温度が少し下がったタイミングでも確認すると特徴を拾いやすい。",
			imageURL:    "https://images.unsplash.com/photo-1521302080334-4bebac2763a6?auto=format&fit=crop&w=1200&q=80",
		},
		{
			titlePrefix: "中煎り豆の選び方",
			slugPrefix:  "medium-roast-selection",
			category:    "beans",
			summary:     "酸味と苦味のバランスを取りたい人向けに、中煎り豆の選び方を整理する。",
			body:        "中煎りは、酸味、甘さ、苦味、コクのバランスを取りやすい焙煎度。初めて買う豆や毎日飲む豆を探す場合は、中煎りから選ぶと失敗しにくい。ナッツ、チョコレート、ブラウンシュガー、オレンジなどの表現がある豆は、飲みやすさと個性の両方を確認しやすい。ミルクを少し入れてもブラックでも飲めるため、保存率の高い候補として扱いやすい。",
			imageURL:    "https://images.unsplash.com/photo-1442512595331-e89e73853f31?auto=format&fit=crop&w=1200&q=80",
		},
		{
			titlePrefix: "深煎りに合うレシピ",
			slugPrefix:  "dark-roast-recipe",
			category:    "recipe",
			summary:     "深煎りの苦味とコクを活かしつつ、重くなりすぎない抽出レシピを考える。",
			body:        "深煎り豆は苦味とコクが出やすい。重くなりすぎる場合は、湯温を少し下げる、抽出時間を短くする、粉量を増やしすぎないといった調整が有効。アイスコーヒーやカフェオレでは深煎りの強さが活きやすく、ミルクや氷で薄まっても味の輪郭が残りやすい。苦味を好む人だけでなく、甘い余韻を求める人にも提案しやすい。",
			imageURL:    "https://images.unsplash.com/photo-1511920170033-f8396924c348?auto=format&fit=crop&w=1200&q=80",
		},
	}

	items := make([]*model.Article, 0, seedArticleCount)
	for i := 0; i < seedArticleCount; i++ {
		pattern := patterns[i%len(patterns)]
		number := i + 1
		title := fmt.Sprintf("%s %03d", pattern.titlePrefix, number)
		slug := fmt.Sprintf("%s-%03d", pattern.slugPrefix, number)
		if i < len(patterns) {
			title = pattern.titlePrefix
			slug = pattern.slugPrefix
		}
		publishedAt := now.Add(-time.Duration(i) * 6 * time.Hour)
		summary := fmt.Sprintf("%s No.%03d。Feed、検索、関連記事、詳細画面の確認に使うSeed記事。", pattern.summary, number)

		items = append(items, &model.Article{
			Title:       title,
			Slug:        slug,
			Summary:     summary,
			Category:    strPtr(pattern.category),
			SourceName:  strPtr("Coffee Ranker Editorial"),
			SourceURL:   strPtr(fmt.Sprintf("https://example.com/articles/%s", slug)),
			ImageURL:    strPtr(pattern.imageURL),
			IsPublished: true,
			PublishedAt: &publishedAt,
		})
	}
	return items
}

func seedBeanArticles(db *gorm.DB, beans []*model.Bean, articles []*model.Article) error {
	if len(beans) == 0 || len(articles) == 0 {
		return nil
	}

	for index, bean := range beans {
		articleIndexes := []int{
			index % len(articles),
			(index + len(articles)/3) % len(articles),
			(index + len(articles)*2/3) % len(articles),
		}
		for displayOrder, articleIndex := range articleIndexes {
			relation := &model.BeanArticle{
				BeanID:       bean.ID,
				ArticleID:    articles[articleIndex].ID,
				DisplayOrder: displayOrder + 1,
			}
			if err := db.Clauses(clause.OnConflict{
				Columns:   []clause.Column{{Name: "bean_id"}, {Name: "article_id"}},
				DoUpdates: clause.AssignmentColumns([]string{"display_order"}),
			}).Create(relation).Error; err != nil {
				return err
			}
		}
	}
	return nil
}

func seedRankTargets(db *gorm.DB, beans []*model.Bean, articles []*model.Article) ([]*model.RankTarget, error) {
	targets := make([]*model.RankTarget, 0, len(beans)+len(articles))

	for _, bean := range beans {
		target, err := upsertRankTarget(db, entity.ContentTypeBean, bean.ID)
		if err != nil {
			return nil, err
		}
		targets = append(targets, target)
	}

	for _, article := range articles {
		target, err := upsertRankTarget(db, entity.ContentTypeArticle, article.ID)
		if err != nil {
			return nil, err
		}
		targets = append(targets, target)
	}

	return targets, nil
}

func seedContentMetrics(db *gorm.DB, targets []*model.RankTarget, now time.Time) error {
	periodEnd := now
	periodStart := now.Add(-24 * time.Hour)

	for index, target := range targets {
		impressionCount := int64(120 + index*7)
		contentViewCount := int64(40 + index*3)
		clickCount := int64(12 + index%30)
		saveCount := int64(4 + index%18)
		ratingCount := int64(8 + index%22)
		goodCount := int64(5 + index%18)
		if goodCount > ratingCount {
			goodCount = ratingCount
		}
		badCount := ratingCount - goodCount
		modalImpressionCount := int64(6 + index%20)
		modalClickCount := int64(1 + index%6)
		if modalClickCount > modalImpressionCount {
			modalClickCount = modalImpressionCount
		}
		modalCloseCount := modalImpressionCount - modalClickCount

		metric := &model.ContentMetric{
			RankTargetID:         target.ID,
			Score:                1000 - float64(index*3) + float64(index%11),
			ImpressionCount:      impressionCount,
			ContentViewCount:     contentViewCount,
			ClickCount:           clickCount,
			StayTotalMs:          180000 + int64(index%40)*15000,
			SaveCount:            saveCount,
			RatingCount:          ratingCount,
			GoodCount:            goodCount,
			BadCount:             badCount,
			ReSearchCount:        int64(index % 9),
			RatingAvg:            safeRate(goodCount-badCount, ratingCount),
			GoodRate:             safeRate(goodCount, ratingCount),
			BadRate:              safeRate(badCount, ratingCount),
			ModalImpressionCount: modalImpressionCount,
			ModalClickCount:      modalClickCount,
			ModalCloseCount:      modalCloseCount,
			ClickRate:            safeRate(clickCount, impressionCount),
			SaveRate:             safeRate(saveCount, contentViewCount),
			ReSearchRate:         safeRate(int64(index%9), contentViewCount),
			ModalClickRate:       safeRate(modalClickCount, modalImpressionCount),
			ModalCloseRate:       safeRate(modalCloseCount, modalImpressionCount),
			PeriodStart:          periodStart,
			PeriodEnd:            periodEnd,
			CalculatedAt:         now,
		}
		if err := upsertContentMetric(db, metric); err != nil {
			return err
		}
	}
	return nil
}

func seedAdminInterestProfiles(db *gorm.DB, userID uint64, now time.Time) error {
	expiresAt := now.Add(30 * 24 * time.Hour)
	profiles := []*model.InterestProfile{
		{UserID: &userID, Dimension: entity.InterestDimensionOrigin, Value: "Ethiopia", Score: 10, LastEventAt: now, ExpiresAt: &expiresAt},
		{UserID: &userID, Dimension: entity.InterestDimensionOrigin, Value: "Kenya", Score: 8, LastEventAt: now, ExpiresAt: &expiresAt},
		{UserID: &userID, Dimension: entity.InterestDimensionOrigin, Value: "Colombia", Score: 7, LastEventAt: now, ExpiresAt: &expiresAt},
		{UserID: &userID, Dimension: entity.InterestDimensionRoastLevel, Value: string(entity.RoastLevelLight), Score: 8, LastEventAt: now, ExpiresAt: &expiresAt},
		{UserID: &userID, Dimension: entity.InterestDimensionRoastLevel, Value: string(entity.RoastLevelMedium), Score: 6, LastEventAt: now, ExpiresAt: &expiresAt},
		{UserID: &userID, Dimension: entity.InterestDimensionAcidity, Value: "5", Score: 6, LastEventAt: now, ExpiresAt: &expiresAt},
		{UserID: &userID, Dimension: entity.InterestDimensionFlavor, Value: "5", Score: 5, LastEventAt: now, ExpiresAt: &expiresAt},
		{UserID: &userID, Dimension: entity.InterestDimensionArticleCategory, Value: "brewing", Score: 5, LastEventAt: now, ExpiresAt: &expiresAt},
		{UserID: &userID, Dimension: entity.InterestDimensionArticleCategory, Value: "roast", Score: 4, LastEventAt: now, ExpiresAt: &expiresAt},
		{UserID: &userID, Dimension: entity.InterestDimensionArticleCategory, Value: "beans", Score: 4, LastEventAt: now, ExpiresAt: &expiresAt},
	}

	for _, profile := range profiles {
		if err := upsertUserInterestProfile(db, profile); err != nil {
			return err
		}
	}
	return nil
}

func upsertBean(db *gorm.DB, bean *model.Bean) error {
	var existing model.Bean
	err := db.Where("name = ?", bean.Name).First(&existing).Error
	if err == nil {
		bean.ID = existing.ID
		existing.Roaster = bean.Roaster
		existing.Origin = bean.Origin
		existing.Region = bean.Region
		existing.Farm = bean.Farm
		existing.Variety = bean.Variety
		existing.RoastLevel = bean.RoastLevel
		existing.Acidity = bean.Acidity
		existing.Bitterness = bean.Bitterness
		existing.Flavor = bean.Flavor
		existing.Aroma = bean.Aroma
		existing.Body = bean.Body
		existing.FlavorNote = bean.FlavorNote
		existing.Description = bean.Description
		existing.ImageURL = bean.ImageURL
		existing.IsPublished = bean.IsPublished
		return db.Save(&existing).Error
	}
	if !errors.Is(err, gorm.ErrRecordNotFound) {
		return err
	}
	return db.Create(bean).Error
}

func upsertArticle(db *gorm.DB, article *model.Article) error {
	var existing model.Article
	err := db.Where("slug = ?", article.Slug).First(&existing).Error
	if err == nil {
		article.ID = existing.ID
		existing.Title = article.Title
		existing.Summary = article.Summary
		existing.Body = article.Body
		existing.Category = article.Category
		existing.SourceName = article.SourceName
		existing.SourceURL = article.SourceURL
		existing.ImageURL = article.ImageURL
		existing.IsPublished = article.IsPublished
		existing.PublishedAt = article.PublishedAt
		return db.Save(&existing).Error
	}
	if !errors.Is(err, gorm.ErrRecordNotFound) {
		return err
	}
	return db.Create(article).Error
}

func upsertRankTarget(db *gorm.DB, contentType entity.ContentType, contentID uint64) (*model.RankTarget, error) {
	target := &model.RankTarget{ContentType: contentType, ContentID: contentID, IsActive: true}
	if err := db.Clauses(clause.OnConflict{
		Columns:   []clause.Column{{Name: "content_type"}, {Name: "content_id"}},
		DoUpdates: clause.AssignmentColumns([]string{"is_active"}),
	}).Create(target).Error; err != nil {
		return nil, err
	}

	var saved model.RankTarget
	if err := db.Where("content_type = ? AND content_id = ?", contentType, contentID).First(&saved).Error; err != nil {
		return nil, err
	}
	return &saved, nil
}

func upsertContentMetric(db *gorm.DB, metric *model.ContentMetric) error {
	return db.Clauses(clause.OnConflict{
		Columns: []clause.Column{{Name: "rank_target_id"}},
		DoUpdates: clause.AssignmentColumns([]string{
			"score",
			"impression_count",
			"content_view_count",
			"click_count",
			"stay_total_ms",
			"save_count",
			"rating_count",
			"good_count",
			"bad_count",
			"re_search_count",
			"rating_avg",
			"good_rate",
			"bad_rate",
			"modal_impression_count",
			"modal_click_count",
			"modal_close_count",
			"click_rate",
			"save_rate",
			"re_search_rate",
			"modal_click_rate",
			"modal_close_rate",
			"period_start",
			"period_end",
			"calculated_at",
		}),
	}).Create(metric).Error
}

func upsertUserInterestProfile(db *gorm.DB, profile *model.InterestProfile) error {
	if profile.UserID == nil {
		return nil
	}

	var existing model.InterestProfile
	err := db.Where("user_id = ? AND guest_session_id IS NULL AND dimension = ? AND value = ?", *profile.UserID, profile.Dimension, profile.Value).First(&existing).Error
	if err == nil {
		profile.ID = existing.ID
		existing.Score = profile.Score
		existing.LastEventAt = profile.LastEventAt
		existing.ExpiresAt = profile.ExpiresAt
		return db.Save(&existing).Error
	}
	if !errors.Is(err, gorm.ErrRecordNotFound) {
		return err
	}
	return db.Create(profile).Error
}

func rotateTaste(base int, offset int) int {
	value := ((base + offset - 1) % 5) + 1
	if value < 1 {
		return 1
	}
	if value > 5 {
		return 5
	}
	return value
}

func safeRate(numerator int64, denominator int64) float64 {
	if denominator <= 0 {
		return 0
	}
	return float64(numerator) / float64(denominator)
}

func strPtr(value string) *string {
	return &value
}

func intPtr(value int) *int {
	return &value
}
